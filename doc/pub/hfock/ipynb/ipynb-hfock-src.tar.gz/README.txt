This IPython notebook hfock.ipynb does not require any additional
programs.
